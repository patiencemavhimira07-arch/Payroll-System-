import java.sql.*;

public class DBConnection {

    public static Connection connect() {
        try {
            Class.forName("com.mysql.jdbc.Driver");

            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/payroll_db2",
                "root",
                ""
            );

            System.out.println("Database connected!");
            return conn;

        } catch (Exception e) {
            System.out.println("Connection error: " + e.getMessage());
            return null;
        }
    }
}
