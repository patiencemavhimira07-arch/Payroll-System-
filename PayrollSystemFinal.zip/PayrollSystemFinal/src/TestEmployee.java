public class TestEmployee {
    public static void main(String[] args) {

        Employee emp = new Employee();

        emp.addEmployee("John Doe", "Manager", "HR", 1500);
    }
}
