import javax.swing.*;
import java.awt.*;

public class BaseForm extends JFrame {

    private Image bg;

    public BaseForm() {

        // Load your image
        bg = new ImageIcon(getClass().getResource("/images/payroll_image.png")).getImage();

        // Set background panel
        setContentPane(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                // Draw image stretched full screen
                g.drawImage(bg, 0, 0, getWidth(), getHeight(), this);
            }
        });

        setLayout(null); // so buttons/textboxes still show properly
    }
}
