import java.sql.Connection;
import java.sql.DriverManager;

public class TestDB {
    public static void main(String[] args) {

        try {

            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/payroll_db",
                "root",
                ""
            );

            System.out.println("CONNECTED SUCCESSFULLY!");

        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
}
