import java.sql.Connection;
import java.sql.PreparedStatement;
import java.awt.print.PrinterException;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class EmployeeForm2 extends BaseForm {

    /**
     * Creates new form EmployeeForm2
     */
    public EmployeeForm2(){
        super();
        initComponents();
        loadEmployees();
    }
public void loadEmployees(){
    
        try {

            Connection conn = DBConnection.connect();

            String sql = "SELECT * FROM employees";

            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            javax.swing.table.DefaultTableModel model =
                (javax.swing.table.DefaultTableModel) tblEmployees.getModel();

            model.setRowCount(0);

            while (rs.next()) {

                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("position"),
                    rs.getString("department"),
                    rs.getDouble("salary")
                });

            }

        } catch (Exception e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnSave = new javax.swing.JButton();
        txtName = new javax.swing.JTextField();
        txtDepartment = new javax.swing.JTextField();
        txtSalary = new javax.swing.JTextField();
        txtPosition = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblEmployees = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        btnDelete = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        btnShowAll = new javax.swing.JButton();
        btnCalculateSalary = new javax.swing.JButton();
        txtTax = new javax.swing.JTextField();
        txtPension = new javax.swing.JTextField();
        txtNetSalary = new javax.swing.JTextField();
        btnGeneratePayslip = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAreaPayslip = new javax.swing.JTextArea();
        btnPrintPayslip = new javax.swing.JButton();
        btnSavePayslip = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setText("Position");

        jLabel3.setText("Salary");

        btnSave.setText("Save Employee");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        tblEmployees.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Employee Name", "Position", "Department", "Salary"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Float.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tblEmployees.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblEmployeesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblEmployees);

        jLabel5.setText("Employee Name");

        btnDelete.setText("Delete Employee");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnUpdate.setText("Update Employee");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        jLabel6.setText("Search Employee");

        btnSearch.setText("Search Employee");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        btnShowAll.setText("Show All");
        btnShowAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowAllActionPerformed(evt);
            }
        });

        btnCalculateSalary.setText("Calculate Salary");
        btnCalculateSalary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalculateSalaryActionPerformed(evt);
            }
        });

        btnGeneratePayslip.setText("Generate Payslip");
        btnGeneratePayslip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGeneratePayslipActionPerformed(evt);
            }
        });

        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        txtAreaPayslip.setColumns(20);
        txtAreaPayslip.setRows(5);
        jScrollPane2.setViewportView(txtAreaPayslip);

        btnPrintPayslip.setText("Print Payslip");
        btnPrintPayslip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintPayslipActionPerformed(evt);
            }
        });

        btnSavePayslip.setText("Save Payslip");
        btnSavePayslip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSavePayslipActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnDelete)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(67, 67, 67)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnClear)
                            .addComponent(btnShowAll))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCalculateSalary)
                .addGap(102, 102, 102)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnGeneratePayslip)
                        .addGap(113, 113, 113))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnPrintPayslip)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSavePayslip)
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)))
                                    .addComponent(btnSave))
                                .addGap(48, 48, 48)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(txtTax, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(110, 110, 110)
                                                .addComponent(btnUpdate)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                                                .addComponent(txtNetSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(txtSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(txtPension, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(24, 24, 24))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnSearch)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(txtTax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPosition, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtPension, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addComponent(txtDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSave)
                            .addComponent(btnDelete)
                            .addComponent(btnUpdate)
                            .addComponent(txtNetSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnShowAll)
                    .addComponent(btnGeneratePayslip)
                    .addComponent(btnCalculateSalary))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSearch)
                    .addComponent(btnClear)
                    .addComponent(btnPrintPayslip)
                    .addComponent(btnSavePayslip))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
   public void clearFields() {
        txtName.setText("");
        txtPosition.setText("");
        txtSalary.setText("");
        txtDepartment.setText("");
    }
    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
     try {

    System.out.println("Connecting to DB...");

    Connection conn = DBConnection.connect();

    String sql = "INSERT INTO employees (name, position, salary, department) VALUES (?, ?, ?, ?)";

    PreparedStatement pst = conn.prepareStatement(sql);

    pst.setString(1, txtName.getText());
    pst.setString(2, txtPosition.getText());
    pst.setDouble(3, Double.parseDouble(txtSalary.getText()));
    pst.setString(4, txtDepartment.getText());

    int rows = pst.executeUpdate();

   if (rows > 0) {
    System.out.println("Employee added successfully!");
    loadEmployees();   // ✅ refresh table immediately
    clearFields();     // optional (we add this below)
}

} catch (Exception e) {
    System.out.println("ERROR OCCURRED:");
    e.printStackTrace();
}  // TODO add your handling code here:
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
try {

    int row = tblEmployees.getSelectedRow();

    if (row == -1) {
        System.out.println("Please select an employee to delete");
        return;
    }

    int id = Integer.parseInt(tblEmployees.getValueAt(row, 0).toString());

    Connection conn = DBConnection.connect();

    String sql = "DELETE FROM employees WHERE id=?";

    PreparedStatement pst = conn.prepareStatement(sql);
    pst.setInt(1, id);

    int rows = pst.executeUpdate();

    if (rows > 0) {
        System.out.println("Employee deleted successfully!");
        loadEmployees();
    }

} catch (Exception e) {
    e.printStackTrace();
}        // TODO add your handling code here:
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void tblEmployeesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblEmployeesMouseClicked
        int row = tblEmployees.getSelectedRow();

txtName.setText(tblEmployees.getValueAt(row, 1).toString());
txtPosition.setText(tblEmployees.getValueAt(row, 2).toString());
txtDepartment.setText(tblEmployees.getValueAt(row, 3).toString());
txtSalary.setText(tblEmployees.getValueAt(row, 4).toString());// TODO add your handling code here:
    }//GEN-LAST:event_tblEmployeesMouseClicked

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        try {

    int row = tblEmployees.getSelectedRow();

    if (row == -1) {
        System.out.println("Select employee first!");
        return;
    }

    int id = Integer.parseInt(
        tblEmployees.getValueAt(row, 0).toString()
    );

    Connection conn = DBConnection.connect();

    String sql = "UPDATE employees SET name=?, position=?, salary=?, department=? WHERE id=?";

    PreparedStatement pst = conn.prepareStatement(sql);

    pst.setString(1, txtName.getText());
    pst.setString(2, txtPosition.getText());
    pst.setDouble(3, Double.parseDouble(txtSalary.getText()));
    pst.setString(4, txtDepartment.getText());
    pst.setInt(5, id);

    int rows = pst.executeUpdate();

    if (rows > 0) {
        System.out.println("Employee updated successfully!");
        loadEmployees();
        clearFields();
    }

} catch (Exception e) {
    e.printStackTrace();
}// TODO add your handling code here:
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
    try {

    String searchText = txtSearch.getText().trim();

    System.out.println("Search button clicked");
    System.out.println("Searching for: " + searchText);

    Connection conn = DBConnection.connect();

    String sql = "SELECT * FROM employees WHERE LOWER(name) LIKE LOWER(?)";

    PreparedStatement pst = conn.prepareStatement(sql);
    pst.setString(1, "%" + searchText + "%");

    ResultSet rs = pst.executeQuery();

    DefaultTableModel model =
        (DefaultTableModel) tblEmployees.getModel();

    model.setRowCount(0);

  boolean found = false;

while (rs.next()) {
    found = true;
    txtName.setText(rs.getString("name"));
txtPosition.setText(rs.getString("position"));
txtSalary.setText(String.valueOf(rs.getDouble("salary")));

    model.addRow(new Object[]{
        rs.getInt("id"),
        rs.getString("name"),
        rs.getString("position"),
        rs.getString("department"),
        rs.getDouble("salary")
    });

    System.out.println("Row found");
}

if (!found) {
    javax.swing.JOptionPane.showMessageDialog(
        null,
        "Employee not found!"
    );

    model.setRowCount(0); // ensure table is empty
}

    rs.close();
    pst.close();
    conn.close();

} catch (Exception e) {
    e.printStackTrace();
}    // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchActionPerformed

    private void btnShowAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowAllActionPerformed
   loadEmployees();     // TODO add your handling code here:
    }//GEN-LAST:event_btnShowAllActionPerformed

    private void btnCalculateSalaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalculateSalaryActionPerformed
    double salary = Double.parseDouble(txtSalary.getText());

double tax = salary * 0.10;
double pension = salary * 0.05;
double deductions = tax + pension;

double netSalary = salary - deductions;

txtTax.setText(String.valueOf(tax));
txtPension.setText(String.valueOf(pension));
txtNetSalary.setText(String.valueOf(netSalary));    // TODO add your handling code here:
    }//GEN-LAST:event_btnCalculateSalaryActionPerformed

    private void btnGeneratePayslipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGeneratePayslipActionPerformed
        String name = txtName.getText();
    String position = txtPosition.getText();
    double salary = Double.parseDouble(txtSalary.getText());

    double tax = salary * 0.10;
    double pension = salary * 0.05;
    double netSalary = salary - (tax + pension);

    txtTax.setText(String.valueOf(tax));
    txtPension.setText(String.valueOf(pension));
    txtNetSalary.setText(String.valueOf(netSalary));

    // 👉 PASTE YOUR PAYSLIP STRING HERE
    String payslip =
            "=================================\n" +
            "         EMPLOYEE PAYSLIP        \n" +
            "=================================\n" +
            "Name: " + name + "\n" +
            "Position: " + position + "\n" +
            "---------------------------------\n" +
            "Basic Salary: " + salary + "\n" +
            "Tax (10%): " + tax + "\n" +
            "Pension (5%): " + pension + "\n" +
            "---------------------------------\n" +
            "NET SALARY: " + netSalary + "\n" +
            "=================================";

   txtAreaPayslip.setText(payslip);  // TODO add your handling code here:
    }//GEN-LAST:event_btnGeneratePayslipActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
  txtName.setText("");
txtPosition.setText("");
txtSalary.setText("");
txtTax.setText("");
txtPension.setText("");
txtNetSalary.setText("");
txtAreaPayslip.setText("");
txtSearch.setText("");      // TODO add your handling code here:
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnPrintPayslipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintPayslipActionPerformed
      try {

    boolean complete = txtAreaPayslip.print();

    if (complete) {
        javax.swing.JOptionPane.showMessageDialog(null,
                "Payslip printed successfully!");
    } else {
        javax.swing.JOptionPane.showMessageDialog(null,
                "Printing cancelled");
    }

} catch (PrinterException e) {
    javax.swing.JOptionPane.showMessageDialog(null,
            "Printing failed: " + e.getMessage());
}  // TODO add your handling code here:
    }//GEN-LAST:event_btnPrintPayslipActionPerformed

    private void btnSavePayslipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSavePayslipActionPerformed
try {

    String name = txtName.getText();
    String position = txtPosition.getText();

    double salary = Double.parseDouble(txtSalary.getText());
    double tax = salary * 0.10;
    double pension = salary * 0.05;
    double netSalary = salary - (tax + pension);

    String payslipText = txtAreaPayslip.getText();

    Connection conn = DBConnection.connect();

    String sql = "INSERT INTO payslips "
            + "(employee_name, position, basic_salary, tax, pension, net_salary, payslip_text) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?)";

    PreparedStatement pst = conn.prepareStatement(sql);

    pst.setString(1, name);
    pst.setString(2, position);
    pst.setDouble(3, salary);
    pst.setDouble(4, tax);
    pst.setDouble(5, pension);
    pst.setDouble(6, netSalary);
    pst.setString(7, payslipText);

    int rows = pst.executeUpdate();

    if (rows > 0) {
        javax.swing.JOptionPane.showMessageDialog(null,
                "Payslip saved to database!");
    }

    pst.close();
    conn.close();

} catch (Exception e) {
    javax.swing.JOptionPane.showMessageDialog(null,
            "Error saving payslip: " + e.getMessage());
}        // TODO add your handling code here:
    }//GEN-LAST:event_btnSavePayslipActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployeeForm2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployeeForm2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployeeForm2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployeeForm2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployeeForm2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalculateSalary;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnGeneratePayslip;
    private javax.swing.JButton btnPrintPayslip;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnSavePayslip;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnShowAll;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblEmployees;
    private javax.swing.JTextArea txtAreaPayslip;
    private javax.swing.JTextField txtDepartment;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtNetSalary;
    private javax.swing.JTextField txtPension;
    private javax.swing.JTextField txtPosition;
    private javax.swing.JTextField txtSalary;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtTax;
    // End of variables declaration//GEN-END:variables
}
